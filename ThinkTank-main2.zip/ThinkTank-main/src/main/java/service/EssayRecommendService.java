package service;

public class EssayRecommendService {
    
}
